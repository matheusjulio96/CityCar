package com.example.matheus.citycar;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

public class MainActivity extends AppCompatActivity {

    private ListView opcoes;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        String[] itens = {this.getString(R.string.txt_solicitar_veiculo),
                this.getString(R.string.txt_minhas_locacoes),
                this.getString(R.string.txt_acionar_socorro),
                this.getString(R.string.txt_minha_locacao),

                "Cadastrar Veiculo","Obter Info. Veiculo"};

        opcoes = (ListView) findViewById(R.id.opcoes);

        ArrayAdapter<String> adaptador = new ArrayAdapter<String>(this,android.R.layout.simple_list_item_1,android.R.id.text1, itens);
        opcoes.setAdapter(adaptador);

        final Class[] telas = {
                Activity_user_solicita_veiculo.class,
                Activity_user_ve_locacoes.class,
                Activity_user_aciona_socorro.class,
                Activity_user_ve_solicitacao.class,

                Activity_ger_cad_veiculo.class,Activity_ger_obt_info_veiculo.class};

        opcoes.setOnItemClickListener(
                new AdapterView.OnItemClickListener() {
                    @Override
                    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                        Intent intent = new Intent(MainActivity.this, telas[position]); //intent para verificar se há recursos no aparelho
                        startActivity(intent);
                    }
                }
        );
    }
}
