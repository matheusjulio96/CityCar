package com.example.matheus.citycar;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

public class Activity_user_ve_locacoes extends AppCompatActivity {

    private ListView locacoes;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_ve_locacoes);

        setTitle(this.getString(R.string.txt_minhas_locacoes));

        String[] itens = {"Fusca Azul - 03/05/17","Fusca Preto - 04/05/17"};//solicitacoes

        locacoes = (ListView) findViewById(R.id.locacoes);

        ArrayAdapter<String> adaptador = new ArrayAdapter<String>(this,android.R.layout.simple_list_item_1,android.R.id.text1, itens);
        locacoes.setAdapter(adaptador);
    }
}
