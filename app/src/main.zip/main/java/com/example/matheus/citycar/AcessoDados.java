package com.example.matheus.citycar;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

/**
 * Created by matheus on 10/05/17.
 */

public class AcessoDados extends SQLiteOpenHelper {

    public AcessoDados(Context context) {
        super(context/**/, "citycarbd"/*nome banco*/, null, 1);
        //Apagar o banco quando for necessário alguma
        //alteração na estrutura
        //context.deleteDatabase("citycarbd");//delete banco de dados
    }

    @Override
    public void onCreate(SQLiteDatabase banco) {//todas as tabelas vão ser criadas através do método onCreate
        String DDL = "CREATE TABLE veiculo(placa TEXT PRIMARY KEY, marca TEXT, modelo TEXT," +
                "ano TEXT, combustivel TEXT,chassi TEXT)";
        banco.execSQL(DDL);
    }

    @Override
    public void onUpgrade(SQLiteDatabase banco, int oldVersion, int newVersion) {//os drops,alter vão ser feitos através do metodo onUPgrade
        banco.execSQL("DROP TABLE IF EXISTS veiculo");
    }

    public void insertVeiculo(Veiculo veiculo) {//método insert
        SQLiteDatabase banco = this.getWritableDatabase();
        ContentValues valores = new ContentValues();
        valores.put("placa", veiculo.getPlaca());
        valores.put("marca", veiculo.getMarca());
        valores.put("modelo", veiculo.getModelo());
        valores.put("ano", veiculo.getAno());
        valores.put("combustivel", veiculo.getCombustivel());
        valores.put("chassi", veiculo.getChassi());
        banco.insert("veiculo", null, valores);
    }

    public Veiculo consultaVeiculo(String placa) { //método consulta
        try{
            SQLiteDatabase banco = this.getReadableDatabase();

            Cursor campo = banco.query("veiculo", new String[]{
                    "marca", "modelo", "ano", "combustivel", "chassi"
            }, "placa = '" + placa+"'", null, null, null, null, null);

            if (campo != null)
                campo.moveToFirst();

            Veiculo veiculo = new Veiculo();
            veiculo.setPlaca(placa);
            veiculo.setMarca(campo.getString(0));
            veiculo.setModelo(campo.getString(1));
            veiculo.setAno(campo.getString(2));
            veiculo.setCombustivel(campo.getString(3));
            veiculo.setChassi(campo.getString(4));
            campo.close();
            return veiculo;
        }catch(SecurityException e){
            Veiculo veiculo = new Veiculo();
            veiculo.setModelo(e.getMessage());
            return veiculo;
        }
    }

    public int getNumeroRegistroVeiculo(){
        String consulta = "SELECT * FROM veiculo";
        SQLiteDatabase banco = this.getReadableDatabase();
        Cursor campo = banco.rawQuery(consulta, null);
        int numeroRegistros = campo.getCount();
        campo.close();
        return numeroRegistros;
    }
}