package com.example.matheus.citycar;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Spinner;

public class Activity_user_solicita_veiculo extends AppCompatActivity {

    private String array_spinner[];

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_solicita_veiculo);

        setTitle(R.string.txt_solicitacao_veiculo);

        array_spinner = new String[3];
        array_spinner[0] = "1";
        array_spinner[1] = "2";
        array_spinner[2] = "3";
        Spinner spnPeriodo = (Spinner) findViewById(R.id.spinner_Periodo);
        ArrayAdapter adapter = new ArrayAdapter(this, R.layout.spinner_item, array_spinner);
        spnPeriodo.setAdapter(adapter);
    }
}
